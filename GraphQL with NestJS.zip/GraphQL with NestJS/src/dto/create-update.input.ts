
// src/book/dto/update-book.input.ts
import { InputType, Field, ID } from '@nestjs/graphql';

@InputType()
export class updatedBook {
    @Field(() => ID)  // ID type for primary key
    id: string;

    @Field()
    title: string;

    @Field()
    author: string;
}
