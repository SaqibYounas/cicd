import { Controller } from '@nestjs/common';

@Controller('prisma')
export class PrismaController {}
