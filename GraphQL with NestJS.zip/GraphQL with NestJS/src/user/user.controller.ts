import { Controller, Get, Post } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';

@Controller('users')
export class UserController {

  @Get()
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  getAll() {
    return "This is a rate limit api";
  }


}
