import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { BookService } from './book.service';
import { Book } from './model/book.model';
import { CreateBookInput } from '../dto/create-book.input';
import { updatedBook } from '../dto/create-update.input';

@Resolver(() => Book)
export class BookResolver {
    constructor(private readonly bookService: BookService) { }

    // GET ALL BOOKS
    @Query(() => [Book])
    getAllBooks() {
        return this.bookService.findAll();
    }

    // GET ONE BOOK
    @Query(() => Book)
    getBook(@Args('id') id: string) {
        return this.bookService.findOne(id);
    }

    // CREATE BOOK
    @Mutation(() => Book)
    createBook(@Args('input') input: CreateBookInput) {
        return this.bookService.create(input);
    }

    // UPDATE BOOK
    @Mutation(() => Book)
    updateBook(@Args('input') input: updatedBook) {
        return this.bookService.update(input);
    }

    // DELETE BOOK
    @Mutation(() => Book)
    deleteBook(@Args('id') id: string) {
        return this.bookService.remove(id);
    }
}
