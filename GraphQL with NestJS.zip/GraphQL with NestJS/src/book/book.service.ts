import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateBookInput } from '../dto/create-book.input';
import { updatedBook } from '../dto/create-update.input';

@Injectable()
export class BookService {
    constructor(private prisma: PrismaService) { }

    // CREATE
    create(data: CreateBookInput) {
        return this.prisma.book.create({ data });
    }

    // FIND ALL
    findAll() {
        return this.prisma.book.findMany();
    }

    // FIND ONE
    findOne(id: string) {
        return this.prisma.book.findUnique({
            where: { id },
        });
    }

    // UPDATE
    update(data: updatedBook) {
        return this.prisma.book.update({
            where: { id: data.id },
            data: {
                title: data.title,
                author: data.author,
            },
        });
    }

    // DELETE
    remove(id: string) {
        return this.prisma.book.delete({
            where: { id },
        });
    }
}
